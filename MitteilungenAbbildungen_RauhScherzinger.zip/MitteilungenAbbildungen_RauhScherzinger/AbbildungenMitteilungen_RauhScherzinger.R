# Abbildungen 1 & 2
# für Rauh/Scherzinger "Widersprüchliche Signale", WZB Mitteilungen

library(tidyverse)
library(Hmisc)
library(extrafont)
library(scales)
library(ggrepel)
library(here)



# Abbildung 1 ####

# Daten 
df <- read.csv2(here("DatenAbb1.csv"), header = T, sep = ";")

# Abbildung
ggplot(df, aes(x = year, y = lss.fit, label = country)) +
  geom_hline(yintercept = 0, linetype = "dashed")+
  geom_vline(xintercept = c(1979.5, 1994.5, 1999.5, 2008.5, 2013.5, 2015.5), linetype = "dashed")+
  geom_vline(xintercept = 1991.5)+
  stat_smooth(method = "loess", span = .3, color = "black", fill = NA, size = 0.5, linetype = "dotted")+
  geom_jitter(width = .2, alpha = .8, shape = 16, size = 2, aes(color = lss.fit))+
  scale_colour_gradient2(low = "red",
                         high = "green3",
                         mid = "grey70",
                         midpoint = 0, 
                         limits = c(-1.5,1.5),
                         oob=squish)+
  annotate(geom = "text", 
           label = c("Afghanistan", "Ende der\nSowjetunion", "Tschetschenien I", "Tschetschenien II", "Georgien", "Krim Annexion", "Syrien"), 
           x = c(1979, 1990.5, 1994, 1999, 2008, 2013, 2015), 
           y = -3.7, angle = 90, hjust = 0, vjust = 0.4, size = 3, family = "Dahrendorf")+
  scale_x_continuous(breaks = seq(1970, 2020, 5))+
  coord_cartesian(ylim = c(-3.5, 3.5)) +
  labs(title = "Wie EU-Staaten vor den Vereinten Nationen über Russland gesprochen haben",
       caption = "Die Datenpunkte repräsentieren die Sätze aus Reden von EU Staaten vor der UN Vollversammlung, die Russland bzw. die Sowjetunion als handelnden Akteur benennen.\nDer Wert auf der y-Achse zeigt an, ob die dabei verwendete Sprache eher konfliktbetont oder eher kooperativ ist.",
       y = "Betonung von\nKonflikt vs. Kooperation\n",
       x = "")+
  theme_bw()+
  theme(legend.position = "none",
        plot.title = element_text(face = "bold"),
        text = element_text(family = "Dahrendorf"),
        axis.text = element_text(color = "black"),
        panel.grid = element_blank())

# Export png
ggsave(here("Abbildung1.png"), width = 26.5, height = 18, units = "cm")

# Export vector graphic
ggsave(here("Abbildung1.svg"), width = 26.5, height = 18, units = "cm")



# Abbildung 2 ####

# Daten 
df2 <- read.csv2(here("DatenAbb2.csv"), header = T, sep = ";")

# Abbildung
ggplot(df2, aes(y=lss, x = freq, alpha = freq, color = lss, label = country2))+
  geom_hline(yintercept = 0, linetype = "dashed")+
  geom_label_repel(family = "Dahrendorf", fontface = "bold", fill = "white")+
  scale_color_gradient2(low = "red",
                        high = "green3",
                        mid = "grey70",
                        midpoint = 0, 
                        na.value = "white",
                        limits = c(-1.2,1.2),
                        oob=squish)+
  scale_alpha_continuous(range = c(.7,1))+
  labs(title = "Russland in UN Reden einzelner EU-Staaten ",
       subtitle = "Nach der Krim Annexion (2014-2020)",
       x = "\nHäufigkeit von Sätzen,\ndie Russland als handelnden Akteur benennen\n",
       y = "Durchschnittliche Betonung von\nKonflikt vs. Kooperation\n",
       # caption = "Textdaten von Mikhaylov et al. (2017). Role Labelling, Skalierung und Plot: @ChRauh."
  ) +
  theme_bw()+
  theme(legend.position = "none",
        plot.title = element_text(face = "bold"),
        text = element_text(family = "Dahrendorf"),
        axis.text = element_text(color = "black"))

# Export
ggsave(here("Abbildung2.png"), width = 26.5, height = 16, units = "cm")

# Export vector graphic
ggsave(here("Abbildung2.svg"), width = 26.5, height = 16, units = "cm")